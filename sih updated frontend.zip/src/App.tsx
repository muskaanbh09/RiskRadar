import { useState } from 'react';
import LoginPage from './views/LoginPage';
import WorkerFlow from './views/WorkerFlow';
import OfficerDashboard from './views/OfficerDashboard';

export type Role = 'worker' | 'officer';
type AppScreen = 'login' | 'worker' | 'dashboard';

export default function App() {
  const [screen, setScreen] = useState<AppScreen>('login');
  const [role, setRole] = useState<Role>('worker');

  function loginWorker() { setRole('worker'); setScreen('worker'); }
  function loginOfficer() { setRole('officer'); setScreen('dashboard'); }
  function logout() { setScreen('login'); }

  return (
    <div className="h-full">
      {screen === 'login' && (
        <LoginPage onLoginWorker={loginWorker} onLoginOfficer={loginOfficer} />
      )}
      {screen === 'worker' && (
        <WorkerFlow onSwitchToDashboard={() => { setRole('officer'); setScreen('dashboard'); }} onLogout={logout} role={role} />
      )}
      {screen === 'dashboard' && (
        <OfficerDashboard onSwitchToWorker={() => { setRole('worker'); setScreen('worker'); }} onLogout={logout} role={role} />
      )}
    </div>
  );
}
